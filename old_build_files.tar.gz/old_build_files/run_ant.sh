#!/bin/bash

ant -buildfile biscicol_tests_ant.xml $1

