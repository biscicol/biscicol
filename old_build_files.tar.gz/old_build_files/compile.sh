#!/bin/sh
#MacOS Java
#JAVA=/System/Library/Frameworks/JavaVM.framework/Versions/1.6/Home/bin/java
#Redhat Java
#JAVA=/usr/bin/javac
#LOADFILE=Load.properties
#$JAVA -sourcepath src -classpath out/production/Biscicol:lib/* src/*.java -d out

ant -buildfile biscicol-unix.xml
